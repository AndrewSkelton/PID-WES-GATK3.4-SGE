#!/bin/bash
declare -a arrayname=(element1 element2 element3)

printf "%s\n" "${arrayname[@]}"
